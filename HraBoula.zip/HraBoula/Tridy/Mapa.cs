﻿namespace HraBoula.Tridy
{
    public class Mapa
    {
    }
}
