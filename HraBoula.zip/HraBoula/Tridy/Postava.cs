﻿namespace HraBoula.Tridy
{
    public class Postava
    {
        public string Zmacknuto { get; set; }
        public string name { get; set; }
        public string top { get; set; } = "40px";
        public string left { get; set; } = "0px";

        public void PohybHrace(string klavesa)
        {
            switch (klavesa)
            {
                case "w":
                    if (int.Parse(top.Replace("px", "")) > 40)
                    {
                        top = $"{int.Parse(top.Replace("px", "")) - 40}px";
                        name = top;
                    }
                    break;
                case "s":
                    if (int.Parse(top.Replace("px", "")) < 480)
                    {
                        top = $"{int.Parse(top.Replace("px", "")) + 40}px";
                        name = top;
                    }
                    break;
                case "a":
                    if (int.Parse(left.Replace("px", "")) > 0)
                    {
                        left = $"{int.Parse(left.Replace("px", "")) - 40}px";
                        name = left;
                    }
                    break;
                case "d":
                   if (int.Parse(left.Replace("px", "")) < 1120)
                    {
                        left = $"{int.Parse(left.Replace("px", "")) + 40}px";
                        name = left;
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
